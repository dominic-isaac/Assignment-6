import java.math.BigInteger;
/*
   Author:  Dominic Molina
   Purpose: Manages message signing and signature 
*/
public class MsgSigning {

    //Computes the hash of the message
    public static BigInteger computeHash(String message) {
        byte[] bytes = message.getBytes();
        int sum = 0;
        for(byte b : bytes) {
            sum += b;
        }
        return BigInteger.valueOf(sum);
    }

    //helps with signing messages
    public static BigInteger signMessage(String message, BigInteger privateKey, BigInteger modulus) {
        BigInteger hash = computeHash(message);
        return hash.modPow(privateKey, modulus);
    }
    //helps verifying messages
    public static boolean verifySignature(String message, BigInteger signature, BigInteger publicKey, BigInteger modulus) {
        BigInteger hash = computeHash(message);
        BigInteger decryptedHash = signature.modPow(publicKey, modulus);
        return hash.equals(decryptedHash);
    }
}
