import java.math.BigInteger;
/*
   Author:  Dominic Molina
   Purpose: Handles communication between individuals including compression, encryption and signing.
*/

public class Communication {

   //send a compressed message
   public static Message sendCompressedMessage(Person sender, Person receiver, String messageBody) {
      //Compress the message using run-length encoding
      String compressedBody = RunLength.encode(messageBody);

      //Create metadata indicating that the message is compressed
      String metadata = "Compressed:RunLengthEncoding";

      Message message = new Message(sender.getId(), receiver.getId(), metadata, compressedBody);
      return message;
   }

   // Method for the receiver to decompress the message
   public static String receiveCompressedMessage(Message message) {
      String compressedBody = message.getBody();
      // Decompress the message
      String originalBody = RunLength.decode(compressedBody);
      return originalBody;
   }

   //Send an encrypted message using RSA
   public static Message sendEncryptedMessage(Person sender, Person receiver, String messageBody) {
      //Encrypt the message body using the receiver's public key
      BigInteger encryptedMessage = RSAEncrypt.encrypt(messageBody, receiver.getPublicKey(), receiver.getModulus());

      //Create metadata indicating that the message is encrypted
      String metadata = "Encrypted:RSA";
      String encryptedBody = encryptedMessage.toString(16); 

      Message message = new Message(sender.getId(), receiver.getId(), metadata, encryptedBody);

      return message;
   }

   //Receiver to decrypt the message
   public static String receiveEncryptedMessage(Person receiver, Message message) {
      //Get the encrypted message 
      String encryptedBody = message.getBody();
      BigInteger encryptedMessage = new BigInteger(encryptedBody, 16);

      //Decrypt the message using receiver's key
      String decryptedMessage = RSAEncrypt.decrypt(encryptedMessage, receiver.getPrivateKey(), receiver.getModulus());
      return decryptedMessage;
   }

   //Sends a signed message and receive a signed confirmation
   public static Message sendSignedMessage(Person sender, Person receiver, String messageBody) {
      
      BigInteger hash = MsgSigning.computeHash(messageBody);
      BigInteger signature = hash.modPow(sender.getPrivateKey(), sender.getModulus());
      //Create metadata indicating that the file is signed
      String metadata = "Signed:RSA";
      String bodyWithSignature = messageBody + "|" + signature.toString(16); 
      Message message = new Message(sender.getId(), receiver.getId(), metadata, bodyWithSignature);

      return message;
   }

   //Receiver to verify the signed message and send confirmation
   public static Message receiveSignedMessageAndSendConfirmation(Person receiver, Message message, Person sender) {
      //Extract the message body and signature
      String[] parts = message.getBody().split("\\|");
      String receivedMessageBody = parts[0];
      BigInteger receivedSignature = new BigInteger(parts[1], 16);

      boolean isValid = MsgSigning.verifySignature(receivedMessageBody, receivedSignature, sender.getPublicKey(), sender.getModulus());
      String confirmationBody = "Message received and " + (isValid ? "valid" : "invalid");
      BigInteger confirmationHash = MsgSigning.computeHash(confirmationBody);
      BigInteger confirmationSignature = confirmationHash.modPow(receiver.getPrivateKey(), receiver.getModulus());
      String metadata = "Confirmation:Signed";
      String confirmationMessageBody = confirmationBody + "|" +
            " OriginalSignature:" + receivedSignature.toString(16) + "|" +
            " OriginalHash:" + MsgSigning.computeHash(receivedMessageBody).toString(16) + "|" +
            " ConfirmationHash:" + confirmationHash.toString(16) + "|" +
            " ConfirmationSignature:" + confirmationSignature.toString(16);

      Message confirmationMessage = new Message(receiver.getId(), sender.getId(), metadata, confirmationMessageBody);

      return confirmationMessage;
   }

   //Processes the confirmation message
   public static void processConfirmationMessage(Person sender, Message confirmationMessage, Person receiver) {
      String[] parts = confirmationMessage.getBody().split("\\|");
      String confirmationBody = parts[0];

      BigInteger originalReceivedSignature = new BigInteger(parts[1].split(":")[1], 16);
      BigInteger originalHash = new BigInteger(parts[2].split(":")[1], 16);
      BigInteger confirmationHash = new BigInteger(parts[3].split(":")[1], 16);
      BigInteger confirmationSignature = new BigInteger(parts[4].split(":")[1], 16);

      // Verify the confirmation signature using receiver'skey
      boolean isConfirmationValid = confirmationHash.equals(confirmationSignature.modPow(receiver.getPublicKey(), receiver.getModulus()));

      if (isConfirmationValid) {
         System.out.println("Confirmation message is valid.");
         System.out.println("Confirmation message: " + confirmationBody);
      } else {
         System.out.println("Confirmation message is invalid.");
      }
   }
}
