public class Main {
    public static void main(String[] args) {
        
        //Create a new empty graph
        Graph graph = new Graph();

        //Assign People to be added to the graph
        Person Dominic = new Person("Dominic");
        Person Kyle = new Person("Kyle");
        Person Christine = new Person("Christine");
        Person Christian = new Person("Christian");
        
        graph.addPerson(Dominic);
        graph.addPerson(Kyle);
        graph.addPerson(Christine);
        graph.addPerson(Christian);
        
        graph.addConnection("Christine", "Dominic");
        graph.addConnection("Dominic", "Kyle");
        graph.addConnection("Kyle", "Christian");

        //First Task sest cases
        //Send compressed message from Christine to Christian
        //Christian will receive the message and decompresses it
        String messageBody = "Compression Testing";
        Message compressedMessage = Communication.sendCompressedMessage(Christine, Christian, messageBody);
        System.out.println("Compressed text message sent from " + compressedMessage.getSenderId() + " to " + compressedMessage.getReceiverId());
        System.out.println("Compressed text message: " + compressedMessage.getBody());
        String decompressedMessage = Communication.receiveCompressedMessage(compressedMessage);
        System.out.println("Christian received and decompressed the text message: " + decompressedMessage);

        //Second Task test case
        //Send encrypted message from Dominic to Kyle
        //Kyle receives the message and decrypts it
        String secretMessage = "Hello Kyle, I'm testing encryption";
        Message encryptedMessage = Communication.sendEncryptedMessage(Dominic, Kyle, secretMessage);
        System.out.println("Encrypted text message sent from " + encryptedMessage.getSenderId() + " to " + encryptedMessage.getReceiverId());
        System.out.println("Encrypted text message: " + encryptedMessage.getBody());
        String decryptedMessage = Communication.receiveEncryptedMessage(Kyle, encryptedMessage);
        System.out.println("Kyle decrypted the text message: " + decryptedMessage);


        //Third Task 
        //Christian sends a signed message to Christine 
        //Chrisitne will confirm that she recieved the message
        String importantMessage = "Please review the attached text:";
        Message signedMessage = Communication.sendSignedMessage(Christian, Christine, importantMessage);
        System.out.println("Signed message sent from " + signedMessage.getSenderId() + " to " + signedMessage.getReceiverId());
        System.out.println("Signed message body: " + signedMessage.getBody());
        Message confirmationMessage = Communication.receiveSignedMessageAndSendConfirmation(Christine, signedMessage, Christian);
        System.out.println("Confirmation message sent from " + confirmationMessage.getSenderId() + " to " + confirmationMessage.getReceiverId());
        System.out.println("Confirmation message " + confirmationMessage.getBody());
        Communication.processConfirmationMessage(Christian, confirmationMessage, Christine);
    }
}
