import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/*
   Author:  Dominic Molina
   Purpose: Manages the network of people and their connections
*/

public class Graph {
   private Map<String, Person> persons; 
   private Map<String, Set<String>> connections; 

   //Creates a new graph
   public Graph() {
      persons = new HashMap<>();
      connections = new HashMap<>();
   }

   public void addPerson(Person person) {
      persons.put(person.getId(), person);
      connections.putIfAbsent(person.getId(), new HashSet<>());
   }

   public void addConnection(String personId1, String personId2) {
      connections.get(personId1).add(personId2);
      connections.get(personId2).add(personId1);
   }

   public Person getPerson(String id) {
      return persons.get(id);
   }

   public boolean areConnected(String id1, String id2) {
      return connections.get(id1).contains(id2);
   }
}
