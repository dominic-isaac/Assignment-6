import java.math.BigInteger;
import java.security.SecureRandom;

/*
   Author:  DominiC Molina
   Purpose: RSA key generation for encryption and signing.
*/

public class Person {
    private String id; 
    private BigInteger publicKey; 
    private BigInteger privateKey; 
    private BigInteger modulus; 

    public Person(String id) {
        this.id = id;
        // Generate RSA keys for this person
        generateRSAKeys();
    }

    public String getId() {
        return id;
    }

    public BigInteger getPublicKey() {
        return publicKey;
    }

    public BigInteger getModulus() {
        return modulus;
    }

    public BigInteger getPrivateKey() {
        return privateKey;
    }

    //generates the RSA keys
    private void generateRSAKeys() {
        int bitLength = 512; 
        SecureRandom random = new SecureRandom();
        BigInteger x = BigInteger.probablePrime(bitLength / 2, random);
        BigInteger y = BigInteger.probablePrime(bitLength / 2, random);
        modulus = x.multiply(y);
        BigInteger a = (x.subtract(BigInteger.ONE)).multiply(y.subtract(BigInteger.ONE));
        publicKey = BigInteger.probablePrime(bitLength / 2, random);

        while (a.gcd(publicKey).intValue() > 1) {
            publicKey = publicKey.add(BigInteger.ONE);
        }

        privateKey = publicKey.modInverse(a);
    }
}
