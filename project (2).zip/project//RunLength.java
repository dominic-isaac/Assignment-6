
/*
   Author:  Dominic Molina
   Purpose: Provides methods for run-length encoding and decoding of messages.
*/
public class RunLength {

    //performs run-length encoding on string
    public static String encode(String input) {
        StringBuilder encoded = new StringBuilder();
        int count = 1;
        char prev = input.charAt(0);

        for(int i = 1; i < input.length(); i++) {
            char curr = input.charAt(i);
            if(curr == prev) {
                count++;
            } else {
                encoded.append(prev);
                encoded.append(count);
                prev = curr;
                count = 1;
            }
        }
        encoded.append(prev);
        encoded.append(count);
        return encoded.toString();
    }

    //ecodes a run-length encoded string
    public static String decode(String input) {
        StringBuilder decoded = new StringBuilder();

        for(int i = 0; i < input.length(); i += 2) {
            char c = input.charAt(i);
            int count = Character.getNumericValue(input.charAt(i+1));
            for(int j = 0; j < count; j++) {
                decoded.append(c);
            }
        }
        return decoded.toString();
    }
}
