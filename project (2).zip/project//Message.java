
/*
   Author:  Dominic Molina
   Purpose: Contains messages with sender, receiver, metadata, and body.
*/
public class Message {
    private String senderId;
    private String receiverId;
    private String metadata;
    private String body;

    public Message(String senderId, String receiverId, String metadata, String body) {
        this.senderId = senderId;
        this.receiverId = receiverId;
        this.metadata = metadata;
        this.body = body;
    }

    public String getSenderId() {
        return senderId;
    }

    public String getReceiverId() {
        return receiverId;
    }

    public String getMetadata() {
        return metadata;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }
}
