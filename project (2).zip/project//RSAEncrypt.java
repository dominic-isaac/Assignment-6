import java.math.BigInteger;

/*
   Author:  Dominic Molina
   Purpose: Handles RSA encryption and decryption of messages.
*/

public class RSAEncrypt {

    //encrypts using RSA
    public static BigInteger encrypt(String message, BigInteger publicKey, BigInteger modulus) {
        return new BigInteger(message.getBytes()).modPow(publicKey, modulus);
    }

    //decrypts using RSA
    public static String decrypt(BigInteger encryptedMessage, BigInteger privateKey, BigInteger modulus) {
        BigInteger decrypted = encryptedMessage.modPow(privateKey, modulus);
        return new String(decrypted.toByteArray());
    }
}
